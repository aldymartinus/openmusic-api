const autoBind = require('auto-bind');

/* eslint-disable require-jsdoc */
class Listener {
  constructor(playlistsService, mailSender) {
    this._playlistsService = playlistsService;
    this._mailSender = mailSender;

    autoBind(this);
  }

  async listen(msg) {
    try {
      const {playlistId, targetEmail} = JSON.parse(
          msg.content.toString(),
      );

      const playlists = await this._playlistsService.getListOfSongs(playlistId);
      await this._mailSender.sendMail(targetEmail, JSON.stringify(playlists,
          null, 2));
    } catch (error) {
      console.error(error);
    }
  }
}

module.exports = Listener;

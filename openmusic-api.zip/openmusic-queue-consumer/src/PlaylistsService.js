/* eslint-disable require-jsdoc */
const {Pool} = require('pg');
const InvariantError = require('./exceptions/InvariantError');

class PlaylistsService {
  constructor() {
    this._pool = new Pool();
  }

  async getListOfSongs(playlistId) {
    const query = {
      text: `select name, songs.id, songs.title, songs.performer from playlists 
      left join playlist_songs on playlists.id = playlist_songs.playlist_id 
      left join songs on playlist_songs.song_id = songs.id  
      WHERE playlists.id = $1`,
      values: [playlistId],
    };

    const queryRes = await this._pool.query(query);
    const playlist = queryRes.rows;

    if (!queryRes.rowCount) throw new InvariantError('Playlist tidak valid');

    const songs = playlist.map((song) => ({
      id: song.id,
      title: song.title,
      performer: song.performer,
    }));

    const res = ({
      playlist: {
        id: playlistId,
        name: playlist[0].name,
        songs,
      },
    });

    return res;
  }
}

module.exports = PlaylistsService;

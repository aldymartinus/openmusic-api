/* eslint-disable require-jsdoc */
const autoBind = require('auto-bind');

class AlbumHandler {
  constructor(service, validator, uploadValidator, storageService) {
    this._service = service;
    this._validator = validator;
    this._uploadValidator = uploadValidator;
    this._storageService = storageService;

    autoBind(this);
  }

  async postAlbumHandler(req, h) {
    this._validator.validateAlbumPayload(req.payload);
    const {name, year} = req.payload;
    const albumId = await this._service.addAlbum({name, year});

    const res = h.response({
      status: 'success',
      data: {
        albumId,
      },
    });
    res.code(201);
    return res;
  }

  async getAlbumsHandler() {
    const albums = await this._service.getAlbums();

    return {
      status: 'success',
      data: {
        albums,
      },
    };
  }

  async getAlbumByIdHandler(req) {
    const {id} = req.params;
    const album = await this._service.getAlbumById(id);
    const songs = await this._service.getSongList(id);
    album.songs = songs;

    return {
      status: 'success',
      data: {
        album,
      },
    };
  }

  async putAlbumByIdHandler(req) {
    this._validator.validateAlbumPayload(req.payload);
    const {id} = req.params;
    await this._service.editAlbumById(id, req.payload);

    return {
      status: 'success',
      message: 'Album berhasil diperbarui',
    };
  }

  async deleteAlbumByIdHandler(req) {
    const {id} = req.params;
    await this._service.deleteAlbumById(id);

    return {
      status: 'success',
      message: 'Album berhasil dihapus',
    };
  }

  async postLikeToAlbumHandler(req, h) {
    const {id: albumId} = req.params;
    const {id: credentialId} = req.auth.credentials;

    await this._service.likeAlbumById(albumId, credentialId);

    const res = h.response({
      status: 'success',
      message: `${credentialId} menyukai sebuah album`,
    });
    res.code(201);

    return res;
  }

  async getLikesFromAlbumHandler(req, h) {
    const {id: albumId} = req.params;
    const albumLikes = await this._service.getAlbumLikesCountById(albumId);
    const likes = albumLikes.likes;

    const res = h.response({
      status: 'success',
      data: {
        likes,
      },
    });

    res.header('X-Data-Source', albumLikes.header);
    return res;
  }

  async deleteLikeFromAlbumHandler(req) {
    const {id: albumId} = req.params;
    const {id: credentialId} = req.auth.credentials;
    await this._service.deleteAlbumLikeById(albumId, credentialId);

    return {
      status: 'success',
      message: 'Album batal disukai',
    };
  }

  async postUploadAlbumCoverHandler(req, h) {
    const data = req.payload;
    const coverData = data.cover.hapi;
    const {id: albumId} = req.params;
    this._uploadValidator.validateImageHeaders(coverData.headers);
    const fname = await this._storageService.writeFile(data.cover, coverData);
    const url = `http://${process.env.HOST}:${process.env.PORT}/albums/upload/file/images/${fname}`;
    await this._service.addCoverUrlToAlbum(albumId, url);

    const res = h.response({
      status: 'success',
      message: 'Sampul berhasil diunggah',
    });
    res.code(201);

    return res;
  }
}

module.exports = AlbumHandler;

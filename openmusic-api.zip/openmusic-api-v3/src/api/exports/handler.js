const autoBind = require('auto-bind');

/* eslint-disable require-jsdoc */
class ExportsHandler {
  constructor(service, validator, playlistService) {
    this._validator = validator;
    this._service = service;
    this._playlistService = playlistService;
    autoBind(this);
  }

  async postExportPlaylistsHandler(req, h) {
    const username = req.auth.credentials.id;
    const {id: playistId} = req.params;

    this._validator.validateExportPlaylistsPayload(req.payload);
    await this._playlistService.verifyPlaylistAccess(playistId, username);
    const message = {
      playlistId: playistId,
      targetEmail: req.payload.targetEmail,
    };

    await this._service.sendMsg('export:playlists', JSON.stringify(message));

    const res = h.response({
      status: 'success',
      message: 'Permintaan Anda dalam antrean',
    });
    res.code(201);

    return res;
  }
}

module.exports = ExportsHandler;
